package presentation;

public class UntitledGaming {

    /* Avvio.*/
    private static void avvio() {
        new startPage();
    }

    /* Main */
    public static void main(String[] args) {
        avvio();
    }
}
